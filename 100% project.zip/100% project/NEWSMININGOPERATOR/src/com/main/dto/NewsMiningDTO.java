package com.main.dto;

public class NewsMiningDTO {

    public NewsMiningDTO() {

    }
    private String id;
    private String category;
    private String token3;
    private String token6;
    private String totalWeight;
    private String byUser;
    private String token1;
    private String token4;
    private String token7;
    private String title;
    private String filePath;
    private String token2;
    private String token5;
    private String token8;
    private String entryDate;

    public String getID() {
        return id;
    }

    public String getCategory() {
        return category;
    }

    public String getToken3() {
        return token3;
    }

    public String getToken6() {
        return token6;
    }

    public String getTotalWeight() {
        return totalWeight;
    }

    public String getByUser() {
        return byUser;
    }

    public String getToken1() {
        return token1;
    }

    public String getToken4() {
        return token4;
    }

    public String getToken7() {
        return token7;
    }

    public String getTitle() {
        return title;
    }

    public String getFilePath() {
        return filePath;
    }

    public String getToken2() {
        return token2;
    }

    public String getToken5() {
        return token5;
    }

    public String getToken8() {
        return token8;
    }

    public String getEntryDate() {
        return entryDate;
    }

    public void setID(String id) {
        this.id = id;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setToken3(String token3) {
        this.token3 = token3;
    }

    public void setToken6(String token6) {
        this.token6 = token6;
    }

    public void setTotalWeight(String totalWeight) {
        this.totalWeight = totalWeight;
    }

    public void setByUser(String byUser) {
        this.byUser = byUser;
    }

    public void setToken1(String token1) {
        this.token1 = token1;
    }

    public void setToken4(String token4) {
        this.token4 = token4;
    }

    public void setToken7(String token7) {
        this.token7 = token7;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public void setToken2(String token2) {
        this.token2 = token2;
    }

    public void setToken5(String token5) {
        this.token5 = token5;
    }

    public void setToken8(String token8) {
        this.token8 = token8;
    }

    public void setEntryDate(String entryDate) {
        this.entryDate = entryDate;
    }
}
