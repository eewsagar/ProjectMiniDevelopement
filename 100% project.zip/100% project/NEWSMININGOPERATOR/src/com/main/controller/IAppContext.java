/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.main.controller;

/**
 *
 */
public interface IAppContext {

    public void exitApplication();
    public String FOLDER_WEBDATA = "webdata";
    public String FOLDER_XML_FORMAT = "xmlformat";
    public String FOLDER_TAG_FILTERED = "tag_filtered";
    public String FOLDER_STOPWORD_FILTERED = "stop_word_filtered";
    public String FOLDER_STEMMED = "stemmed";
   
}
