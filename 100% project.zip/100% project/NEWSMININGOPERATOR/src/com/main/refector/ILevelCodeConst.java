/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.main.refector;

/**
 *
 * @author Pravin
 */
public interface ILevelCodeConst {

    static String LEVEL01 = "L01";
    static String LEVEL02 = "L02";
    static String LEVEL03 = "L03";
    static String LEVEL04 = "L04";
    static String LEVEL05 = "L05";
    static String LEVEL06 = "L06";
    static String LEVEL07 = "L07";
    static String LEVEL08 = "L08";
    static String LEVEL09 = "L09";
    static String LEVEL10 = "L10";
    static String LEVEL11 = "L11";
    static String LEVEL12 = "L12";

    static String LEVEL13 = "L13";
    static String LEVEL14 = "L14";
    static String LEVEL15 = "L15";
    static String LEVEL16 = "L16";

    static String LEVEL01_NAME = "MEMBER";
    static String LEVEL02_NAME = "SENIOR MEMBER";
    static String LEVEL03_NAME = "SIVER MEMBER";
    static String LEVEL04_NAME = "PEARL MEMBER";
    static String LEVEL05_NAME = "JUNIOR RUBY MEMBER";
    static String LEVEL06_NAME = "RUBY MEMBER";
    static String LEVEL07_NAME = "JUNIOR EMERALD MEMBER";
    static String LEVEL08_NAME = "ASSISTANT EMERALD MEMBER";
    static String LEVEL09_NAME = "EMERALD MEMBER";
    static String LEVEL10_NAME = "JUNOR DIAMOND MEMBER";
    static String LEVEL11_NAME = "ASSISTANT DIAMOND MEMBER";
    static String LEVEL12_NAME = "DIAMOND MEMBER";

    static String LEVEL13_NAME = "";
    static String LEVEL14_NAME = "";
    static String LEVEL15_NAME = "";
    static String LEVEL16_NAME = "";

}
